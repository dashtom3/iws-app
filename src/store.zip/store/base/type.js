export const USER_LOGIN = 'USER_LOGIN';
export const USER_GET = 'USER_GET';
export const USER_REGISTER = 'USER_REGISTER';
export const USER_VERI = 'USER_VERI';
export const USER_LOGOUT = 'USER_LOGOUT';

export const SYSTEM_LIST = 'SYSTEM_LIST';
export const NEWS_LIST = 'NEWS_LIST';

export const TABBAR = 'TABBAR';
export const BOTTOMSHEET = 'BOTTOMSHEET';
export const INDICATOR = 'INDICATOR';
